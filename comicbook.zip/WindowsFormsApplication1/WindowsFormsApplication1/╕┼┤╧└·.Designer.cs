﻿namespace WindowsFormsApplication1
{
    partial class 매니저
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend2 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Title title1 = new System.Windows.Forms.DataVisualization.Charting.Title();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.button18 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.button14 = new System.Windows.Forms.Button();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.button13 = new System.Windows.Forms.Button();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.button12 = new System.Windows.Forms.Button();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.dataGridView4 = new System.Windows.Forms.DataGridView();
            this.mIDDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.oIDDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rRENTDATEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bNAMEDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rDEADLINEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rISRETURNDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.rISEXTENDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.rSTAFFDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rENTBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataSet1 = new WindowsFormsApplication1.DataSet1();
            this.button11 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.chart2 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.button7 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.bNAMEDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.oIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.oISRENTDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.oISRESERVEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.oSTATUSDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bOOKOWNBOOKBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bOOKBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.bNAMEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bGENREDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bAUTHORITYDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bPAGEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bFEEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bLATEFEEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bDEADLINEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bLOCATIONDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.button19 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.mIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mPASSWORDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mNAMEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mPHONEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mEMAILDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mLATEFEEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mGRADEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mEMBERBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.chart3 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.button17 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.oracleCommand1 = new Oracle.DataAccess.Client.OracleCommand();
            this.oracleConnection1 = new Oracle.DataAccess.Client.OracleConnection();
            this.bOOKTableAdapter = new WindowsFormsApplication1.DataSet1TableAdapters.BOOKTableAdapter();
            this.oWNBOOKTableAdapter = new WindowsFormsApplication1.DataSet1TableAdapters.OWNBOOKTableAdapter();
            this.mEMBERTableAdapter = new WindowsFormsApplication1.DataSet1TableAdapters.MEMBERTableAdapter();
            this.rENTTableAdapter = new WindowsFormsApplication1.DataSet1TableAdapters.RENTTableAdapter();
            this.button9 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rENTBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart2)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bOOKOWNBOOKBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bOOKBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mEMBERBindingSource)).BeginInit();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart3)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Font = new System.Drawing.Font("휴먼편지체", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tabControl1.Location = new System.Drawing.Point(1, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(867, 548);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.AliceBlue;
            this.tabPage1.Controls.Add(this.button18);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.textBox5);
            this.tabPage1.Controls.Add(this.button14);
            this.tabPage1.Controls.Add(this.comboBox3);
            this.tabPage1.Controls.Add(this.button13);
            this.tabPage1.Controls.Add(this.comboBox4);
            this.tabPage1.Controls.Add(this.button12);
            this.tabPage1.Controls.Add(this.textBox4);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.dataGridView4);
            this.tabPage1.Controls.Add(this.button11);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.dateTimePicker2);
            this.tabPage1.Controls.Add(this.dateTimePicker1);
            this.tabPage1.Controls.Add(this.chart2);
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Font = new System.Drawing.Font("휴먼편지체", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tabPage1.Location = new System.Drawing.Point(4, 31);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(859, 513);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "현황";
            // 
            // button18
            // 
            this.button18.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button18.Font = new System.Drawing.Font("휴먼편지체", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button18.Location = new System.Drawing.Point(750, 235);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(76, 26);
            this.button18.TabIndex = 23;
            this.button18.Text = "저장";
            this.button18.UseVisualStyleBackColor = false;
            this.button18.Click += new System.EventHandler(this.button18_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("휴먼편지체", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label4.Location = new System.Drawing.Point(506, 239);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(86, 22);
            this.label4.TabIndex = 22;
            this.label4.Text = "해야할 일";
            // 
            // textBox5
            // 
            this.textBox5.Font = new System.Drawing.Font("휴먼편지체", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox5.Location = new System.Drawing.Point(510, 270);
            this.textBox5.Multiline = true;
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(315, 234);
            this.textBox5.TabIndex = 21;
            // 
            // button14
            // 
            this.button14.BackColor = System.Drawing.SystemColors.ControlLight;
            this.button14.Font = new System.Drawing.Font("휴먼편지체", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button14.Location = new System.Drawing.Point(443, 3);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(76, 29);
            this.button14.TabIndex = 20;
            this.button14.Text = "초기화";
            this.button14.UseVisualStyleBackColor = false;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // comboBox3
            // 
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Items.AddRange(new object[] {
            "책 제목",
            "책 번호",
            "회원 ID"});
            this.comboBox3.Location = new System.Drawing.Point(59, 5);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(122, 25);
            this.comboBox3.TabIndex = 19;
            // 
            // button13
            // 
            this.button13.Font = new System.Drawing.Font("휴먼편지체", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button13.Location = new System.Drawing.Point(197, 235);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(76, 26);
            this.button13.TabIndex = 17;
            this.button13.Text = "보기";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // comboBox4
            // 
            this.comboBox4.Font = new System.Drawing.Font("휴먼편지체", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Items.AddRange(new object[] {
            "주간",
            "월간"});
            this.comboBox4.Location = new System.Drawing.Point(8, 235);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(122, 28);
            this.comboBox4.TabIndex = 16;
            // 
            // button12
            // 
            this.button12.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button12.Font = new System.Drawing.Font("휴먼편지체", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button12.Location = new System.Drawing.Point(349, 3);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(76, 29);
            this.button12.TabIndex = 15;
            this.button12.Text = "검색";
            this.button12.UseVisualStyleBackColor = false;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(197, 5);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(101, 25);
            this.textBox4.TabIndex = 14;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("휴먼편지체", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label3.Location = new System.Drawing.Point(7, 35);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(61, 22);
            this.label3.TabIndex = 9;
            this.label3.Text = "대여일";
            // 
            // dataGridView4
            // 
            this.dataGridView4.AutoGenerateColumns = false;
            this.dataGridView4.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView4.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.mIDDataGridViewTextBoxColumn1,
            this.oIDDataGridViewTextBoxColumn1,
            this.rRENTDATEDataGridViewTextBoxColumn,
            this.bNAMEDataGridViewTextBoxColumn2,
            this.rDEADLINEDataGridViewTextBoxColumn,
            this.rISRETURNDataGridViewTextBoxColumn,
            this.rISEXTENDDataGridViewTextBoxColumn,
            this.rSTAFFDataGridViewTextBoxColumn});
            this.dataGridView4.DataSource = this.rENTBindingSource;
            this.dataGridView4.Location = new System.Drawing.Point(8, 63);
            this.dataGridView4.Name = "dataGridView4";
            this.dataGridView4.RowTemplate.Height = 23;
            this.dataGridView4.Size = new System.Drawing.Size(846, 166);
            this.dataGridView4.TabIndex = 8;
            // 
            // mIDDataGridViewTextBoxColumn1
            // 
            this.mIDDataGridViewTextBoxColumn1.DataPropertyName = "M_ID";
            this.mIDDataGridViewTextBoxColumn1.HeaderText = "회원 ID";
            this.mIDDataGridViewTextBoxColumn1.Name = "mIDDataGridViewTextBoxColumn1";
            // 
            // oIDDataGridViewTextBoxColumn1
            // 
            this.oIDDataGridViewTextBoxColumn1.DataPropertyName = "O_ID";
            this.oIDDataGridViewTextBoxColumn1.HeaderText = "책 번호";
            this.oIDDataGridViewTextBoxColumn1.Name = "oIDDataGridViewTextBoxColumn1";
            // 
            // rRENTDATEDataGridViewTextBoxColumn
            // 
            this.rRENTDATEDataGridViewTextBoxColumn.DataPropertyName = "R_RENTDATE";
            this.rRENTDATEDataGridViewTextBoxColumn.HeaderText = "대여일";
            this.rRENTDATEDataGridViewTextBoxColumn.Name = "rRENTDATEDataGridViewTextBoxColumn";
            // 
            // bNAMEDataGridViewTextBoxColumn2
            // 
            this.bNAMEDataGridViewTextBoxColumn2.DataPropertyName = "B_NAME";
            this.bNAMEDataGridViewTextBoxColumn2.HeaderText = "책 이름";
            this.bNAMEDataGridViewTextBoxColumn2.Name = "bNAMEDataGridViewTextBoxColumn2";
            // 
            // rDEADLINEDataGridViewTextBoxColumn
            // 
            this.rDEADLINEDataGridViewTextBoxColumn.DataPropertyName = "R_DEADLINE";
            this.rDEADLINEDataGridViewTextBoxColumn.HeaderText = "반납일";
            this.rDEADLINEDataGridViewTextBoxColumn.Name = "rDEADLINEDataGridViewTextBoxColumn";
            // 
            // rISRETURNDataGridViewTextBoxColumn
            // 
            this.rISRETURNDataGridViewTextBoxColumn.DataPropertyName = "R_ISRETURN";
            this.rISRETURNDataGridViewTextBoxColumn.FalseValue = "0";
            this.rISRETURNDataGridViewTextBoxColumn.HeaderText = "반납 여부";
            this.rISRETURNDataGridViewTextBoxColumn.Name = "rISRETURNDataGridViewTextBoxColumn";
            this.rISRETURNDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.rISRETURNDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.rISRETURNDataGridViewTextBoxColumn.TrueValue = "1";
            // 
            // rISEXTENDDataGridViewTextBoxColumn
            // 
            this.rISEXTENDDataGridViewTextBoxColumn.DataPropertyName = "R_ISEXTEND";
            this.rISEXTENDDataGridViewTextBoxColumn.FalseValue = "0";
            this.rISEXTENDDataGridViewTextBoxColumn.HeaderText = "연장 여부";
            this.rISEXTENDDataGridViewTextBoxColumn.Name = "rISEXTENDDataGridViewTextBoxColumn";
            this.rISEXTENDDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.rISEXTENDDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.rISEXTENDDataGridViewTextBoxColumn.TrueValue = "1";
            // 
            // rSTAFFDataGridViewTextBoxColumn
            // 
            this.rSTAFFDataGridViewTextBoxColumn.DataPropertyName = "R_STAFF";
            this.rSTAFFDataGridViewTextBoxColumn.HeaderText = "담당자";
            this.rSTAFFDataGridViewTextBoxColumn.Name = "rSTAFFDataGridViewTextBoxColumn";
            // 
            // rENTBindingSource
            // 
            this.rENTBindingSource.DataMember = "RENT";
            this.rENTBindingSource.DataSource = this.dataSet1;
            // 
            // dataSet1
            // 
            this.dataSet1.DataSetName = "DataSet1";
            this.dataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // button11
            // 
            this.button11.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button11.Font = new System.Drawing.Font("휴먼편지체", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button11.Location = new System.Drawing.Point(534, 32);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(76, 28);
            this.button11.TabIndex = 7;
            this.button11.Text = "검색";
            this.button11.UseVisualStyleBackColor = false;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("굴림", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label2.Location = new System.Drawing.Point(280, 35);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(33, 27);
            this.label2.TabIndex = 6;
            this.label2.Text = "~";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("휴먼편지체", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label1.Location = new System.Drawing.Point(134, 238);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 22);
            this.label1.TabIndex = 5;
            this.label1.Text = "Top 5";
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.CustomFormat = "yyyy-MM-dd";
            this.dateTimePicker2.Location = new System.Drawing.Point(319, 35);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(200, 25);
            this.dateTimePicker2.TabIndex = 4;
            this.dateTimePicker2.Value = new System.DateTime(2019, 11, 27, 0, 0, 0, 0);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CustomFormat = "yyyy-MM-dd";
            this.dateTimePicker1.Location = new System.Drawing.Point(74, 35);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 25);
            this.dateTimePicker1.TabIndex = 3;
            this.dateTimePicker1.Value = new System.DateTime(2019, 11, 27, 0, 0, 0, 0);
            // 
            // chart2
            // 
            this.chart2.BackColor = System.Drawing.Color.AliceBlue;
            chartArea1.Name = "ChartArea1";
            this.chart2.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.chart2.Legends.Add(legend1);
            this.chart2.Location = new System.Drawing.Point(10, 264);
            this.chart2.Name = "chart2";
            series1.ChartArea = "ChartArea1";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Pie;
            series1.Legend = "Legend1";
            series1.Name = "Series1";
            this.chart2.Series.Add(series1);
            this.chart2.Size = new System.Drawing.Size(500, 261);
            this.chart2.TabIndex = 1;
            this.chart2.Text = "chart2";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.groupBox1.Controls.Add(this.textBox3);
            this.groupBox1.Font = new System.Drawing.Font("휴먼편지체", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.groupBox1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.groupBox1.Location = new System.Drawing.Point(708, 6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(141, 51);
            this.groupBox1.TabIndex = 11;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "대여 매출";
            // 
            // textBox3
            // 
            this.textBox3.BackColor = System.Drawing.Color.AliceBlue;
            this.textBox3.Location = new System.Drawing.Point(22, 20);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(101, 27);
            this.textBox3.TabIndex = 10;
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.AliceBlue;
            this.tabPage2.Controls.Add(this.button7);
            this.tabPage2.Controls.Add(this.button6);
            this.tabPage2.Controls.Add(this.button4);
            this.tabPage2.Controls.Add(this.button3);
            this.tabPage2.Controls.Add(this.button2);
            this.tabPage2.Controls.Add(this.button1);
            this.tabPage2.Controls.Add(this.textBox1);
            this.tabPage2.Controls.Add(this.comboBox1);
            this.tabPage2.Controls.Add(this.dataGridView2);
            this.tabPage2.Controls.Add(this.dataGridView1);
            this.tabPage2.Font = new System.Drawing.Font("휴먼편지체", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tabPage2.Location = new System.Drawing.Point(4, 31);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(859, 513);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "용품 관리";
            // 
            // button7
            // 
            this.button7.Font = new System.Drawing.Font("휴먼편지체", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button7.Location = new System.Drawing.Point(673, 312);
            this.button7.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(62, 31);
            this.button7.TabIndex = 12;
            this.button7.Text = "삭제";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button6
            // 
            this.button6.Font = new System.Drawing.Font("휴먼편지체", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button6.Location = new System.Drawing.Point(585, 312);
            this.button6.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(62, 31);
            this.button6.TabIndex = 11;
            this.button6.Text = "추가";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button4.Font = new System.Drawing.Font("휴먼편지체", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button4.Location = new System.Drawing.Point(688, 9);
            this.button4.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(87, 35);
            this.button4.TabIndex = 7;
            this.button4.Text = "저장";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("휴먼편지체", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button3.Location = new System.Drawing.Point(305, 15);
            this.button3.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(62, 27);
            this.button3.TabIndex = 6;
            this.button3.Text = "검색";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("휴먼편지체", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button2.Location = new System.Drawing.Point(387, 15);
            this.button2.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(62, 27);
            this.button2.TabIndex = 5;
            this.button2.Text = "추가";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("휴먼편지체", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button1.Location = new System.Drawing.Point(470, 15);
            this.button1.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(62, 27);
            this.button1.TabIndex = 4;
            this.button1.Text = "삭제";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(133, 15);
            this.textBox1.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(142, 25);
            this.textBox1.TabIndex = 3;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "제목",
            "장르",
            "출판사",
            "저자",
            "요금",
            "반납일",
            "위치"});
            this.comboBox1.Location = new System.Drawing.Point(26, 15);
            this.comboBox1.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(87, 25);
            this.comboBox1.TabIndex = 2;
            // 
            // dataGridView2
            // 
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.bNAMEDataGridViewTextBoxColumn1,
            this.oIDDataGridViewTextBoxColumn,
            this.oISRENTDataGridViewTextBoxColumn,
            this.oISRESERVEDataGridViewTextBoxColumn,
            this.oSTATUSDataGridViewTextBoxColumn});
            this.dataGridView2.DataSource = this.bOOKOWNBOOKBindingSource;
            this.dataGridView2.Location = new System.Drawing.Point(7, 312);
            this.dataGridView2.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowTemplate.Height = 30;
            this.dataGridView2.Size = new System.Drawing.Size(545, 194);
            this.dataGridView2.TabIndex = 1;
            // 
            // bNAMEDataGridViewTextBoxColumn1
            // 
            this.bNAMEDataGridViewTextBoxColumn1.DataPropertyName = "B_NAME";
            this.bNAMEDataGridViewTextBoxColumn1.HeaderText = "책 이름";
            this.bNAMEDataGridViewTextBoxColumn1.Name = "bNAMEDataGridViewTextBoxColumn1";
            // 
            // oIDDataGridViewTextBoxColumn
            // 
            this.oIDDataGridViewTextBoxColumn.DataPropertyName = "O_ID";
            this.oIDDataGridViewTextBoxColumn.HeaderText = "책 번호";
            this.oIDDataGridViewTextBoxColumn.Name = "oIDDataGridViewTextBoxColumn";
            // 
            // oISRENTDataGridViewTextBoxColumn
            // 
            this.oISRENTDataGridViewTextBoxColumn.DataPropertyName = "O_ISRENT";
            this.oISRENTDataGridViewTextBoxColumn.FalseValue = "0";
            this.oISRENTDataGridViewTextBoxColumn.HeaderText = "대여 여부";
            this.oISRENTDataGridViewTextBoxColumn.Name = "oISRENTDataGridViewTextBoxColumn";
            this.oISRENTDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.oISRENTDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.oISRENTDataGridViewTextBoxColumn.TrueValue = "1";
            // 
            // oISRESERVEDataGridViewTextBoxColumn
            // 
            this.oISRESERVEDataGridViewTextBoxColumn.DataPropertyName = "O_ISRESERVE";
            this.oISRESERVEDataGridViewTextBoxColumn.FalseValue = "0";
            this.oISRESERVEDataGridViewTextBoxColumn.HeaderText = "반납 여부";
            this.oISRESERVEDataGridViewTextBoxColumn.Name = "oISRESERVEDataGridViewTextBoxColumn";
            this.oISRESERVEDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.oISRESERVEDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.oISRESERVEDataGridViewTextBoxColumn.TrueValue = "1";
            // 
            // oSTATUSDataGridViewTextBoxColumn
            // 
            this.oSTATUSDataGridViewTextBoxColumn.DataPropertyName = "O_STATUS";
            this.oSTATUSDataGridViewTextBoxColumn.HeaderText = "책 상태";
            this.oSTATUSDataGridViewTextBoxColumn.Name = "oSTATUSDataGridViewTextBoxColumn";
            // 
            // bOOKOWNBOOKBindingSource
            // 
            this.bOOKOWNBOOKBindingSource.DataMember = "BOOK_OWNBOOK";
            this.bOOKOWNBOOKBindingSource.DataSource = this.bOOKBindingSource;
            // 
            // bOOKBindingSource
            // 
            this.bOOKBindingSource.DataMember = "BOOK";
            this.bOOKBindingSource.DataSource = this.dataSet1;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.bNAMEDataGridViewTextBoxColumn,
            this.bGENREDataGridViewTextBoxColumn,
            this.bAUTHORITYDataGridViewTextBoxColumn,
            this.bPAGEDataGridViewTextBoxColumn,
            this.bFEEDataGridViewTextBoxColumn,
            this.bLATEFEEDataGridViewTextBoxColumn,
            this.bDEADLINEDataGridViewTextBoxColumn,
            this.bLOCATIONDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.bOOKBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(8, 58);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 30;
            this.dataGridView1.Size = new System.Drawing.Size(743, 239);
            this.dataGridView1.TabIndex = 0;
            // 
            // bNAMEDataGridViewTextBoxColumn
            // 
            this.bNAMEDataGridViewTextBoxColumn.DataPropertyName = "B_NAME";
            this.bNAMEDataGridViewTextBoxColumn.HeaderText = "이름";
            this.bNAMEDataGridViewTextBoxColumn.Name = "bNAMEDataGridViewTextBoxColumn";
            // 
            // bGENREDataGridViewTextBoxColumn
            // 
            this.bGENREDataGridViewTextBoxColumn.DataPropertyName = "B_GENRE";
            this.bGENREDataGridViewTextBoxColumn.HeaderText = "장르";
            this.bGENREDataGridViewTextBoxColumn.Name = "bGENREDataGridViewTextBoxColumn";
            // 
            // bAUTHORITYDataGridViewTextBoxColumn
            // 
            this.bAUTHORITYDataGridViewTextBoxColumn.DataPropertyName = "B_AUTHORITY";
            this.bAUTHORITYDataGridViewTextBoxColumn.HeaderText = "저자";
            this.bAUTHORITYDataGridViewTextBoxColumn.Name = "bAUTHORITYDataGridViewTextBoxColumn";
            // 
            // bPAGEDataGridViewTextBoxColumn
            // 
            this.bPAGEDataGridViewTextBoxColumn.DataPropertyName = "B_PAGE";
            this.bPAGEDataGridViewTextBoxColumn.HeaderText = "페이지";
            this.bPAGEDataGridViewTextBoxColumn.Name = "bPAGEDataGridViewTextBoxColumn";
            // 
            // bFEEDataGridViewTextBoxColumn
            // 
            this.bFEEDataGridViewTextBoxColumn.DataPropertyName = "B_FEE";
            this.bFEEDataGridViewTextBoxColumn.HeaderText = "요금";
            this.bFEEDataGridViewTextBoxColumn.Name = "bFEEDataGridViewTextBoxColumn";
            // 
            // bLATEFEEDataGridViewTextBoxColumn
            // 
            this.bLATEFEEDataGridViewTextBoxColumn.DataPropertyName = "B_LATEFEE";
            this.bLATEFEEDataGridViewTextBoxColumn.HeaderText = "연체료";
            this.bLATEFEEDataGridViewTextBoxColumn.Name = "bLATEFEEDataGridViewTextBoxColumn";
            // 
            // bDEADLINEDataGridViewTextBoxColumn
            // 
            this.bDEADLINEDataGridViewTextBoxColumn.DataPropertyName = "B_DEADLINE";
            this.bDEADLINEDataGridViewTextBoxColumn.HeaderText = "반납기한";
            this.bDEADLINEDataGridViewTextBoxColumn.Name = "bDEADLINEDataGridViewTextBoxColumn";
            // 
            // bLOCATIONDataGridViewTextBoxColumn
            // 
            this.bLOCATIONDataGridViewTextBoxColumn.DataPropertyName = "B_LOCATION";
            this.bLOCATIONDataGridViewTextBoxColumn.HeaderText = "위치";
            this.bLOCATIONDataGridViewTextBoxColumn.Name = "bLOCATIONDataGridViewTextBoxColumn";
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.AliceBlue;
            this.tabPage3.Controls.Add(this.button19);
            this.tabPage3.Controls.Add(this.button10);
            this.tabPage3.Controls.Add(this.button9);
            this.tabPage3.Controls.Add(this.button8);
            this.tabPage3.Controls.Add(this.button5);
            this.tabPage3.Controls.Add(this.textBox2);
            this.tabPage3.Controls.Add(this.comboBox2);
            this.tabPage3.Controls.Add(this.dataGridView3);
            this.tabPage3.Font = new System.Drawing.Font("휴먼편지체", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tabPage3.Location = new System.Drawing.Point(4, 31);
            this.tabPage3.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(859, 513);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "회원 관리";
            // 
            // button19
            // 
            this.button19.Font = new System.Drawing.Font("휴먼편지체", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button19.Location = new System.Drawing.Point(720, 19);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(132, 45);
            this.button19.TabIndex = 7;
            this.button19.Text = "메일 보내기";
            this.button19.UseVisualStyleBackColor = true;
            this.button19.Click += new System.EventHandler(this.button19_Click);
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button10.Font = new System.Drawing.Font("휴먼편지체", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button10.Location = new System.Drawing.Point(525, 36);
            this.button10.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(71, 28);
            this.button10.TabIndex = 6;
            this.button10.Text = "저장";
            this.button10.UseVisualStyleBackColor = false;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // button5
            // 
            this.button5.Font = new System.Drawing.Font("휴먼편지체", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button5.Location = new System.Drawing.Point(246, 36);
            this.button5.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(71, 28);
            this.button5.TabIndex = 3;
            this.button5.Text = "검색";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(118, 36);
            this.textBox2.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(102, 25);
            this.textBox2.TabIndex = 2;
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "이름",
            "휴대폰 ",
            "메일",
            "등급"});
            this.comboBox2.Location = new System.Drawing.Point(16, 36);
            this.comboBox2.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(87, 25);
            this.comboBox2.TabIndex = 1;
            // 
            // dataGridView3
            // 
            this.dataGridView3.AutoGenerateColumns = false;
            this.dataGridView3.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.mIDDataGridViewTextBoxColumn,
            this.mPASSWORDDataGridViewTextBoxColumn,
            this.mNAMEDataGridViewTextBoxColumn,
            this.mPHONEDataGridViewTextBoxColumn,
            this.mEMAILDataGridViewTextBoxColumn,
            this.mLATEFEEDataGridViewTextBoxColumn,
            this.mGRADEDataGridViewTextBoxColumn});
            this.dataGridView3.DataSource = this.mEMBERBindingSource;
            this.dataGridView3.Location = new System.Drawing.Point(7, 91);
            this.dataGridView3.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.RowTemplate.Height = 30;
            this.dataGridView3.Size = new System.Drawing.Size(846, 292);
            this.dataGridView3.TabIndex = 0;
            this.dataGridView3.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dataGridView3_CellFormatting);
            // 
            // mIDDataGridViewTextBoxColumn
            // 
            this.mIDDataGridViewTextBoxColumn.DataPropertyName = "M_ID";
            this.mIDDataGridViewTextBoxColumn.HeaderText = "ID";
            this.mIDDataGridViewTextBoxColumn.Name = "mIDDataGridViewTextBoxColumn";
            // 
            // mPASSWORDDataGridViewTextBoxColumn
            // 
            this.mPASSWORDDataGridViewTextBoxColumn.DataPropertyName = "M_PASSWORD";
            this.mPASSWORDDataGridViewTextBoxColumn.HeaderText = "PW";
            this.mPASSWORDDataGridViewTextBoxColumn.Name = "mPASSWORDDataGridViewTextBoxColumn";
            // 
            // mNAMEDataGridViewTextBoxColumn
            // 
            this.mNAMEDataGridViewTextBoxColumn.DataPropertyName = "M_NAME";
            this.mNAMEDataGridViewTextBoxColumn.HeaderText = "이름";
            this.mNAMEDataGridViewTextBoxColumn.Name = "mNAMEDataGridViewTextBoxColumn";
            // 
            // mPHONEDataGridViewTextBoxColumn
            // 
            this.mPHONEDataGridViewTextBoxColumn.DataPropertyName = "M_PHONE";
            this.mPHONEDataGridViewTextBoxColumn.HeaderText = "전화번호";
            this.mPHONEDataGridViewTextBoxColumn.Name = "mPHONEDataGridViewTextBoxColumn";
            // 
            // mEMAILDataGridViewTextBoxColumn
            // 
            this.mEMAILDataGridViewTextBoxColumn.DataPropertyName = "M_EMAIL";
            this.mEMAILDataGridViewTextBoxColumn.HeaderText = "이메일";
            this.mEMAILDataGridViewTextBoxColumn.Name = "mEMAILDataGridViewTextBoxColumn";
            // 
            // mLATEFEEDataGridViewTextBoxColumn
            // 
            this.mLATEFEEDataGridViewTextBoxColumn.DataPropertyName = "M_LATEFEE";
            this.mLATEFEEDataGridViewTextBoxColumn.HeaderText = "연체료";
            this.mLATEFEEDataGridViewTextBoxColumn.Name = "mLATEFEEDataGridViewTextBoxColumn";
            // 
            // mGRADEDataGridViewTextBoxColumn
            // 
            this.mGRADEDataGridViewTextBoxColumn.DataPropertyName = "M_GRADE";
            this.mGRADEDataGridViewTextBoxColumn.HeaderText = "회원등급";
            this.mGRADEDataGridViewTextBoxColumn.Name = "mGRADEDataGridViewTextBoxColumn";
            this.mGRADEDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // mEMBERBindingSource
            // 
            this.mEMBERBindingSource.DataMember = "MEMBER";
            this.mEMBERBindingSource.DataSource = this.dataSet1;
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.AliceBlue;
            this.tabPage4.Controls.Add(this.chart3);
            this.tabPage4.Controls.Add(this.button17);
            this.tabPage4.Controls.Add(this.button16);
            this.tabPage4.Controls.Add(this.button15);
            this.tabPage4.Font = new System.Drawing.Font("휴먼편지체", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tabPage4.Location = new System.Drawing.Point(4, 31);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(859, 513);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "통계";
            // 
            // chart3
            // 
            chartArea2.AxisX.Interval = 1D;
            chartArea2.Name = "ChartArea1";
            this.chart3.ChartAreas.Add(chartArea2);
            legend2.Name = "Legend1";
            this.chart3.Legends.Add(legend2);
            this.chart3.Location = new System.Drawing.Point(57, 101);
            this.chart3.Name = "chart3";
            series2.ChartArea = "ChartArea1";
            series2.Legend = "Legend1";
            series2.Name = "대여 횟수";
            this.chart3.Series.Add(series2);
            this.chart3.Size = new System.Drawing.Size(741, 380);
            this.chart3.TabIndex = 3;
            this.chart3.Text = "chart3";
            title1.Name = "통계";
            this.chart3.Titles.Add(title1);
            // 
            // button17
            // 
            this.button17.Font = new System.Drawing.Font("휴먼편지체", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button17.Location = new System.Drawing.Point(370, 32);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(94, 40);
            this.button17.TabIndex = 2;
            this.button17.Text = "회원별";
            this.button17.UseVisualStyleBackColor = true;
            this.button17.Click += new System.EventHandler(this.button17_Click);
            // 
            // button16
            // 
            this.button16.Font = new System.Drawing.Font("휴먼편지체", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button16.Location = new System.Drawing.Point(239, 32);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(94, 40);
            this.button16.TabIndex = 1;
            this.button16.Text = "월별";
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Click += new System.EventHandler(this.button16_Click);
            // 
            // button15
            // 
            this.button15.Font = new System.Drawing.Font("휴먼편지체", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button15.Location = new System.Drawing.Point(108, 32);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(94, 40);
            this.button15.TabIndex = 0;
            this.button15.Text = "요일별";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // oracleCommand1
            // 
            this.oracleCommand1.Connection = this.oracleConnection1;
            this.oracleCommand1.Transaction = null;
            // 
            // oracleConnection1
            // 
            this.oracleConnection1.ConnectionString = "DATA SOURCE=ORARA;USER ID=A5293460;password=qew164712486";
            // 
            // bOOKTableAdapter
            // 
            this.bOOKTableAdapter.ClearBeforeFill = true;
            // 
            // oWNBOOKTableAdapter
            // 
            this.oWNBOOKTableAdapter.ClearBeforeFill = true;
            // 
            // mEMBERTableAdapter
            // 
            this.mEMBERTableAdapter.ClearBeforeFill = true;
            // 
            // rENTTableAdapter
            // 
            this.rENTTableAdapter.ClearBeforeFill = true;
            // 
            // button9
            // 
            this.button9.Font = new System.Drawing.Font("휴먼편지체", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button9.Location = new System.Drawing.Point(433, 36);
            this.button9.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(71, 28);
            this.button9.TabIndex = 5;
            this.button9.Text = "삭제";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button8
            // 
            this.button8.Font = new System.Drawing.Font("휴먼편지체", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button8.Location = new System.Drawing.Point(339, 36);
            this.button8.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(71, 28);
            this.button8.TabIndex = 4;
            this.button8.Text = "추가";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // 매니저
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(868, 560);
            this.Controls.Add(this.tabControl1);
            this.Font = new System.Drawing.Font("새굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Name = "매니저";
            this.Text = "매니저";
            this.Load += new System.EventHandler(this.Form8_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rENTBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart2)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bOOKOWNBOOKBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bOOKBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mEMBERBindingSource)).EndInit();
            this.tabPage4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.chart3)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart2;
       
        private System.Windows.Forms.DataGridView dataGridView1;
        private DataSet1 dataSet1;
        private System.Windows.Forms.BindingSource bOOKBindingSource;
        private DataSet1TableAdapters.BOOKTableAdapter bOOKTableAdapter;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.BindingSource bOOKOWNBOOKBindingSource;
        private DataSet1TableAdapters.OWNBOOKTableAdapter oWNBOOKTableAdapter;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.BindingSource mEMBERBindingSource;
        private DataSet1TableAdapters.MEMBERTableAdapter mEMBERTableAdapter;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Button button10;
        private Oracle.DataAccess.Client.OracleCommand oracleCommand1;
        private Oracle.DataAccess.Client.OracleConnection oracleConnection1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.DataGridView dataGridView4;
        private System.Windows.Forms.BindingSource rENTBindingSource;
        private DataSet1TableAdapters.RENTTableAdapter rENTTableAdapter;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart3;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.DataGridViewTextBoxColumn mIDDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn oIDDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn rRENTDATEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn bNAMEDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn rDEADLINEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn rISRETURNDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn rISEXTENDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn rSTAFFDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn bNAMEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn bGENREDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn bAUTHORITYDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn bPAGEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn bFEEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn bLATEFEEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn bDEADLINEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn bLOCATIONDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn bNAMEDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn oIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn oISRENTDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn oISRESERVEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn oSTATUSDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn mIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn mPASSWORDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn mNAMEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn mPHONEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn mEMAILDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn mLATEFEEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn mGRADEDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button8;
    }
}
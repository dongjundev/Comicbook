﻿namespace WindowsFormsApplication1
{
    partial class 직원
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Oracle.DataAccess.Client.OracleParameter oracleParameter1 = new Oracle.DataAccess.Client.OracleParameter();
            Oracle.DataAccess.Client.OracleParameter oracleParameter2 = new Oracle.DataAccess.Client.OracleParameter();
            Oracle.DataAccess.Client.OracleParameter oracleParameter3 = new Oracle.DataAccess.Client.OracleParameter();
            Oracle.DataAccess.Client.OracleParameter oracleParameter4 = new Oracle.DataAccess.Client.OracleParameter();
            Oracle.DataAccess.Client.OracleParameter oracleParameter5 = new Oracle.DataAccess.Client.OracleParameter();
            Oracle.DataAccess.Client.OracleParameter oracleParameter6 = new Oracle.DataAccess.Client.OracleParameter();
            Oracle.DataAccess.Client.OracleParameter oracleParameter7 = new Oracle.DataAccess.Client.OracleParameter();
            Oracle.DataAccess.Client.OracleParameter oracleParameter8 = new Oracle.DataAccess.Client.OracleParameter();
            this.dataSet1 = new WindowsFormsApplication1.DataSet1();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.button3 = new System.Windows.Forms.Button();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.mIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.oIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rRENTDATEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bNAMEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rDEADLINEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rISRETURNDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.rISEXTENDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.rSTAFFDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rENTBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.bNAMEDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.oIDDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.oISRENTDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.oISRESERVEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.oSTATUSDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.oWNBOOKBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.button9 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.dataGridView5 = new System.Windows.Forms.DataGridView();
            this.mIDDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mPASSWORDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mNAMEDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mPHONEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mEMAILDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mLATEFEEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mGRADEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mEMBERBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.label6 = new System.Windows.Forms.Label();
            this.button5 = new System.Windows.Forms.Button();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.mIDDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mNAMEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mEMAILDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bNAMEDataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rISRETURNDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.lATEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vIEWLATEFEE3BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataSet2 = new WindowsFormsApplication1.DataSet2();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.button4 = new System.Windows.Forms.Button();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.dataGridView4 = new System.Windows.Forms.DataGridView();
            this.bNAMEDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bLOCATIONDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lOCATIONBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.oWNBOOKTableAdapter = new WindowsFormsApplication1.DataSet1TableAdapters.OWNBOOKTableAdapter();
            this.oracleConnection1 = new Oracle.DataAccess.Client.OracleConnection();
            this.oracleCommand1 = new Oracle.DataAccess.Client.OracleCommand();
            this.oracleCommand2 = new Oracle.DataAccess.Client.OracleCommand();
            this.rENTTableAdapter = new WindowsFormsApplication1.DataSet1TableAdapters.RENTTableAdapter();
            this.oracleCommand3 = new Oracle.DataAccess.Client.OracleCommand();
            this.oracleCommand4 = new Oracle.DataAccess.Client.OracleCommand();
            this.oracleCommand5 = new Oracle.DataAccess.Client.OracleCommand();
            this.lOCATIONTableAdapter = new WindowsFormsApplication1.DataSet2TableAdapters.LOCATIONTableAdapter();
            this.vIEW_LATEFEE3TableAdapter = new WindowsFormsApplication1.DataSet2TableAdapters.VIEW_LATEFEE3TableAdapter();
            this.mEMBERTableAdapter = new WindowsFormsApplication1.DataSet1TableAdapters.MEMBERTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rENTBindingSource)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.oWNBOOKBindingSource)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mEMBERBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vIEWLATEFEE3BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet2)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lOCATIONBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // dataSet1
            // 
            this.dataSet1.DataSetName = "DataSet1";
            this.dataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(7, 137);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(98, 36);
            this.button1.TabIndex = 1;
            this.button1.Text = "대여";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(113, 137);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(98, 36);
            this.button2.TabIndex = 2;
            this.button2.Text = "반납";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Font = new System.Drawing.Font("휴먼편지체", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tabControl1.Location = new System.Drawing.Point(3, 13);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(997, 503);
            this.tabControl1.TabIndex = 3;
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.AliceBlue;
            this.tabPage2.Controls.Add(this.button3);
            this.tabPage2.Controls.Add(this.textBox4);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.groupBox3);
            this.tabPage2.Controls.Add(this.groupBox2);
            this.tabPage2.Controls.Add(this.groupBox1);
            this.tabPage2.Font = new System.Drawing.Font("휴먼편지체", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tabPage2.Location = new System.Drawing.Point(4, 31);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(989, 468);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "대여/반납";
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("휴먼편지체", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button3.Location = new System.Drawing.Point(738, 14);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(86, 28);
            this.button3.TabIndex = 13;
            this.button3.Text = "검색";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // textBox4
            // 
            this.textBox4.Font = new System.Drawing.Font("휴먼편지체", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox4.Location = new System.Drawing.Point(584, 14);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(138, 30);
            this.textBox4.TabIndex = 12;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("휴먼편지체", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label4.Location = new System.Drawing.Point(523, 20);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(40, 22);
            this.label4.TabIndex = 1;
            this.label4.Text = "제목";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.dataGridView2);
            this.groupBox3.Location = new System.Drawing.Point(14, 248);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(967, 215);
            this.groupBox3.TabIndex = 11;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "대여 기록";
            // 
            // dataGridView2
            // 
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.mIDDataGridViewTextBoxColumn,
            this.oIDDataGridViewTextBoxColumn,
            this.rRENTDATEDataGridViewTextBoxColumn,
            this.bNAMEDataGridViewTextBoxColumn,
            this.rDEADLINEDataGridViewTextBoxColumn,
            this.rISRETURNDataGridViewTextBoxColumn,
            this.rISEXTENDDataGridViewTextBoxColumn,
            this.rSTAFFDataGridViewTextBoxColumn});
            this.dataGridView2.DataSource = this.rENTBindingSource;
            this.dataGridView2.Location = new System.Drawing.Point(7, 22);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.RowTemplate.Height = 23;
            this.dataGridView2.Size = new System.Drawing.Size(953, 186);
            this.dataGridView2.TabIndex = 0;
            // 
            // mIDDataGridViewTextBoxColumn
            // 
            this.mIDDataGridViewTextBoxColumn.DataPropertyName = "M_ID";
            this.mIDDataGridViewTextBoxColumn.HeaderText = "회원 ID";
            this.mIDDataGridViewTextBoxColumn.Name = "mIDDataGridViewTextBoxColumn";
            this.mIDDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // oIDDataGridViewTextBoxColumn
            // 
            this.oIDDataGridViewTextBoxColumn.DataPropertyName = "O_ID";
            this.oIDDataGridViewTextBoxColumn.HeaderText = "책 번호";
            this.oIDDataGridViewTextBoxColumn.Name = "oIDDataGridViewTextBoxColumn";
            this.oIDDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // rRENTDATEDataGridViewTextBoxColumn
            // 
            this.rRENTDATEDataGridViewTextBoxColumn.DataPropertyName = "R_RENTDATE";
            this.rRENTDATEDataGridViewTextBoxColumn.HeaderText = "대여일";
            this.rRENTDATEDataGridViewTextBoxColumn.Name = "rRENTDATEDataGridViewTextBoxColumn";
            this.rRENTDATEDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // bNAMEDataGridViewTextBoxColumn
            // 
            this.bNAMEDataGridViewTextBoxColumn.DataPropertyName = "B_NAME";
            this.bNAMEDataGridViewTextBoxColumn.HeaderText = "책 이름";
            this.bNAMEDataGridViewTextBoxColumn.Name = "bNAMEDataGridViewTextBoxColumn";
            this.bNAMEDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // rDEADLINEDataGridViewTextBoxColumn
            // 
            this.rDEADLINEDataGridViewTextBoxColumn.DataPropertyName = "R_DEADLINE";
            this.rDEADLINEDataGridViewTextBoxColumn.HeaderText = "반납일";
            this.rDEADLINEDataGridViewTextBoxColumn.Name = "rDEADLINEDataGridViewTextBoxColumn";
            this.rDEADLINEDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // rISRETURNDataGridViewTextBoxColumn
            // 
            this.rISRETURNDataGridViewTextBoxColumn.DataPropertyName = "R_ISRETURN";
            this.rISRETURNDataGridViewTextBoxColumn.FalseValue = "0";
            this.rISRETURNDataGridViewTextBoxColumn.HeaderText = "반납 여부";
            this.rISRETURNDataGridViewTextBoxColumn.Name = "rISRETURNDataGridViewTextBoxColumn";
            this.rISRETURNDataGridViewTextBoxColumn.ReadOnly = true;
            this.rISRETURNDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.rISRETURNDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.rISRETURNDataGridViewTextBoxColumn.TrueValue = "1";
            // 
            // rISEXTENDDataGridViewTextBoxColumn
            // 
            this.rISEXTENDDataGridViewTextBoxColumn.DataPropertyName = "R_ISEXTEND";
            this.rISEXTENDDataGridViewTextBoxColumn.FalseValue = "0";
            this.rISEXTENDDataGridViewTextBoxColumn.HeaderText = "연장 여부";
            this.rISEXTENDDataGridViewTextBoxColumn.Name = "rISEXTENDDataGridViewTextBoxColumn";
            this.rISEXTENDDataGridViewTextBoxColumn.ReadOnly = true;
            this.rISEXTENDDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.rISEXTENDDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.rISEXTENDDataGridViewTextBoxColumn.TrueValue = "1";
            // 
            // rSTAFFDataGridViewTextBoxColumn
            // 
            this.rSTAFFDataGridViewTextBoxColumn.DataPropertyName = "R_STAFF";
            this.rSTAFFDataGridViewTextBoxColumn.HeaderText = "담당자";
            this.rSTAFFDataGridViewTextBoxColumn.Name = "rSTAFFDataGridViewTextBoxColumn";
            this.rSTAFFDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // rENTBindingSource
            // 
            this.rENTBindingSource.DataMember = "RENT";
            this.rENTBindingSource.DataSource = this.dataSet1;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.dataGridView1);
            this.groupBox2.Location = new System.Drawing.Point(14, 62);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(647, 179);
            this.groupBox2.TabIndex = 10;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "보유 재고";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.bNAMEDataGridViewTextBoxColumn1,
            this.oIDDataGridViewTextBoxColumn1,
            this.oISRENTDataGridViewTextBoxColumn,
            this.oISRESERVEDataGridViewTextBoxColumn,
            this.oSTATUSDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.oWNBOOKBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(7, 22);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowTemplate.Height = 23;
            this.dataGridView1.Size = new System.Drawing.Size(625, 151);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // bNAMEDataGridViewTextBoxColumn1
            // 
            this.bNAMEDataGridViewTextBoxColumn1.DataPropertyName = "B_NAME";
            this.bNAMEDataGridViewTextBoxColumn1.HeaderText = "책 이름";
            this.bNAMEDataGridViewTextBoxColumn1.Name = "bNAMEDataGridViewTextBoxColumn1";
            this.bNAMEDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // oIDDataGridViewTextBoxColumn1
            // 
            this.oIDDataGridViewTextBoxColumn1.DataPropertyName = "O_ID";
            this.oIDDataGridViewTextBoxColumn1.HeaderText = "책 번호";
            this.oIDDataGridViewTextBoxColumn1.Name = "oIDDataGridViewTextBoxColumn1";
            this.oIDDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // oISRENTDataGridViewTextBoxColumn
            // 
            this.oISRENTDataGridViewTextBoxColumn.DataPropertyName = "O_ISRENT";
            this.oISRENTDataGridViewTextBoxColumn.FalseValue = "0";
            this.oISRENTDataGridViewTextBoxColumn.HeaderText = "대여 여부";
            this.oISRENTDataGridViewTextBoxColumn.Name = "oISRENTDataGridViewTextBoxColumn";
            this.oISRENTDataGridViewTextBoxColumn.ReadOnly = true;
            this.oISRENTDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.oISRENTDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.oISRENTDataGridViewTextBoxColumn.TrueValue = "1";
            // 
            // oISRESERVEDataGridViewTextBoxColumn
            // 
            this.oISRESERVEDataGridViewTextBoxColumn.DataPropertyName = "O_ISRESERVE";
            this.oISRESERVEDataGridViewTextBoxColumn.FalseValue = "0";
            this.oISRESERVEDataGridViewTextBoxColumn.HeaderText = "예약 여부";
            this.oISRESERVEDataGridViewTextBoxColumn.Name = "oISRESERVEDataGridViewTextBoxColumn";
            this.oISRESERVEDataGridViewTextBoxColumn.ReadOnly = true;
            this.oISRESERVEDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.oISRESERVEDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.oISRESERVEDataGridViewTextBoxColumn.TrueValue = "1";
            // 
            // oSTATUSDataGridViewTextBoxColumn
            // 
            this.oSTATUSDataGridViewTextBoxColumn.DataPropertyName = "O_STATUS";
            this.oSTATUSDataGridViewTextBoxColumn.HeaderText = "책 상태";
            this.oSTATUSDataGridViewTextBoxColumn.Name = "oSTATUSDataGridViewTextBoxColumn";
            this.oSTATUSDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // oWNBOOKBindingSource
            // 
            this.oWNBOOKBindingSource.DataMember = "OWNBOOK";
            this.oWNBOOKBindingSource.DataSource = this.dataSet1;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.textBox1);
            this.groupBox1.Controls.Add(this.textBox2);
            this.groupBox1.Controls.Add(this.textBox3);
            this.groupBox1.Controls.Add(this.button2);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Font = new System.Drawing.Font("휴먼편지체", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.groupBox1.Location = new System.Drawing.Point(667, 61);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(216, 180);
            this.groupBox1.TabIndex = 9;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "대여/반납";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("휴먼편지체", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox1.Location = new System.Drawing.Point(91, 30);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(114, 26);
            this.textBox1.TabIndex = 3;
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("휴먼편지체", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox2.Location = new System.Drawing.Point(91, 62);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(114, 26);
            this.textBox2.TabIndex = 4;
            // 
            // textBox3
            // 
            this.textBox3.Font = new System.Drawing.Font("휴먼편지체", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox3.Location = new System.Drawing.Point(91, 91);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(114, 26);
            this.textBox3.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(14, 101);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(69, 22);
            this.label3.TabIndex = 8;
            this.label3.Text = "회원 ID";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(14, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 22);
            this.label1.TabIndex = 6;
            this.label1.Text = "책이름";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(14, 69);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 22);
            this.label2.TabIndex = 7;
            this.label2.Text = "책번호";
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.AliceBlue;
            this.tabPage1.Controls.Add(this.button9);
            this.tabPage1.Controls.Add(this.button6);
            this.tabPage1.Controls.Add(this.textBox6);
            this.tabPage1.Controls.Add(this.comboBox1);
            this.tabPage1.Controls.Add(this.dataGridView5);
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Controls.Add(this.button5);
            this.tabPage1.Controls.Add(this.dataGridView3);
            this.tabPage1.Font = new System.Drawing.Font("휴먼편지체", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tabPage1.Location = new System.Drawing.Point(4, 31);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(989, 468);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "벌금 ";
            // 
            // button9
            // 
            this.button9.Font = new System.Drawing.Font("휴먼편지체", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button9.Location = new System.Drawing.Point(374, 170);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(75, 26);
            this.button9.TabIndex = 9;
            this.button9.Text = "저장";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button6
            // 
            this.button6.Font = new System.Drawing.Font("휴먼편지체", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button6.Location = new System.Drawing.Point(271, 170);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(75, 26);
            this.button6.TabIndex = 6;
            this.button6.Text = "검색";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(144, 169);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(100, 26);
            this.textBox6.TabIndex = 5;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "회원 ID",
            "회원 이름"});
            this.comboBox1.Location = new System.Drawing.Point(7, 169);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 27);
            this.comboBox1.TabIndex = 4;
            // 
            // dataGridView5
            // 
            this.dataGridView5.AllowUserToAddRows = false;
            this.dataGridView5.AllowUserToDeleteRows = false;
            this.dataGridView5.AutoGenerateColumns = false;
            this.dataGridView5.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dataGridView5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView5.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.mIDDataGridViewTextBoxColumn2,
            this.mPASSWORDDataGridViewTextBoxColumn,
            this.mNAMEDataGridViewTextBoxColumn1,
            this.mPHONEDataGridViewTextBoxColumn,
            this.mEMAILDataGridViewTextBoxColumn1,
            this.mLATEFEEDataGridViewTextBoxColumn,
            this.mGRADEDataGridViewTextBoxColumn});
            this.dataGridView5.DataSource = this.mEMBERBindingSource;
            this.dataGridView5.Location = new System.Drawing.Point(7, 212);
            this.dataGridView5.Name = "dataGridView5";
            this.dataGridView5.RowTemplate.Height = 23;
            this.dataGridView5.Size = new System.Drawing.Size(750, 250);
            this.dataGridView5.TabIndex = 3;
            this.dataGridView5.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dataGridView5_CellFormatting);
            // 
            // mIDDataGridViewTextBoxColumn2
            // 
            this.mIDDataGridViewTextBoxColumn2.DataPropertyName = "M_ID";
            this.mIDDataGridViewTextBoxColumn2.HeaderText = "ID";
            this.mIDDataGridViewTextBoxColumn2.Name = "mIDDataGridViewTextBoxColumn2";
            // 
            // mPASSWORDDataGridViewTextBoxColumn
            // 
            this.mPASSWORDDataGridViewTextBoxColumn.DataPropertyName = "M_PASSWORD";
            this.mPASSWORDDataGridViewTextBoxColumn.HeaderText = "PW";
            this.mPASSWORDDataGridViewTextBoxColumn.Name = "mPASSWORDDataGridViewTextBoxColumn";
            // 
            // mNAMEDataGridViewTextBoxColumn1
            // 
            this.mNAMEDataGridViewTextBoxColumn1.DataPropertyName = "M_NAME";
            this.mNAMEDataGridViewTextBoxColumn1.HeaderText = "이름";
            this.mNAMEDataGridViewTextBoxColumn1.Name = "mNAMEDataGridViewTextBoxColumn1";
            // 
            // mPHONEDataGridViewTextBoxColumn
            // 
            this.mPHONEDataGridViewTextBoxColumn.DataPropertyName = "M_PHONE";
            this.mPHONEDataGridViewTextBoxColumn.HeaderText = "전화번호";
            this.mPHONEDataGridViewTextBoxColumn.Name = "mPHONEDataGridViewTextBoxColumn";
            // 
            // mEMAILDataGridViewTextBoxColumn1
            // 
            this.mEMAILDataGridViewTextBoxColumn1.DataPropertyName = "M_EMAIL";
            this.mEMAILDataGridViewTextBoxColumn1.HeaderText = "메일";
            this.mEMAILDataGridViewTextBoxColumn1.Name = "mEMAILDataGridViewTextBoxColumn1";
            // 
            // mLATEFEEDataGridViewTextBoxColumn
            // 
            this.mLATEFEEDataGridViewTextBoxColumn.DataPropertyName = "M_LATEFEE";
            this.mLATEFEEDataGridViewTextBoxColumn.HeaderText = "벌금";
            this.mLATEFEEDataGridViewTextBoxColumn.Name = "mLATEFEEDataGridViewTextBoxColumn";
            // 
            // mGRADEDataGridViewTextBoxColumn
            // 
            this.mGRADEDataGridViewTextBoxColumn.DataPropertyName = "M_GRADE";
            this.mGRADEDataGridViewTextBoxColumn.HeaderText = "등급";
            this.mGRADEDataGridViewTextBoxColumn.Name = "mGRADEDataGridViewTextBoxColumn";
            // 
            // mEMBERBindingSource
            // 
            this.mEMBERBindingSource.DataMember = "MEMBER";
            this.mEMBERBindingSource.DataSource = this.dataSet1;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("휴먼편지체", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label6.Location = new System.Drawing.Point(6, 18);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(252, 22);
            this.label6.TabIndex = 2;
            this.label6.Text = "* 벌금을 가진 회원 만 보입니다.";
            // 
            // button5
            // 
            this.button5.Font = new System.Drawing.Font("휴먼편지체", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button5.Location = new System.Drawing.Point(819, 53);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(121, 34);
            this.button5.TabIndex = 1;
            this.button5.Text = "메일 보내기";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // dataGridView3
            // 
            this.dataGridView3.AutoGenerateColumns = false;
            this.dataGridView3.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.mIDDataGridViewTextBoxColumn1,
            this.mNAMEDataGridViewTextBoxColumn,
            this.mEMAILDataGridViewTextBoxColumn,
            this.bNAMEDataGridViewTextBoxColumn3,
            this.rISRETURNDataGridViewTextBoxColumn1,
            this.lATEDataGridViewTextBoxColumn});
            this.dataGridView3.DataSource = this.vIEWLATEFEE3BindingSource;
            this.dataGridView3.Location = new System.Drawing.Point(7, 53);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.RowTemplate.Height = 23;
            this.dataGridView3.Size = new System.Drawing.Size(648, 90);
            this.dataGridView3.TabIndex = 0;
            // 
            // mIDDataGridViewTextBoxColumn1
            // 
            this.mIDDataGridViewTextBoxColumn1.DataPropertyName = "M_ID";
            this.mIDDataGridViewTextBoxColumn1.HeaderText = "회원 ID";
            this.mIDDataGridViewTextBoxColumn1.Name = "mIDDataGridViewTextBoxColumn1";
            // 
            // mNAMEDataGridViewTextBoxColumn
            // 
            this.mNAMEDataGridViewTextBoxColumn.DataPropertyName = "M_NAME";
            this.mNAMEDataGridViewTextBoxColumn.HeaderText = "회원 이름";
            this.mNAMEDataGridViewTextBoxColumn.Name = "mNAMEDataGridViewTextBoxColumn";
            // 
            // mEMAILDataGridViewTextBoxColumn
            // 
            this.mEMAILDataGridViewTextBoxColumn.DataPropertyName = "M_EMAIL";
            this.mEMAILDataGridViewTextBoxColumn.HeaderText = "회원 메일";
            this.mEMAILDataGridViewTextBoxColumn.Name = "mEMAILDataGridViewTextBoxColumn";
            // 
            // bNAMEDataGridViewTextBoxColumn3
            // 
            this.bNAMEDataGridViewTextBoxColumn3.DataPropertyName = "B_NAME";
            this.bNAMEDataGridViewTextBoxColumn3.HeaderText = "책 이름";
            this.bNAMEDataGridViewTextBoxColumn3.Name = "bNAMEDataGridViewTextBoxColumn3";
            // 
            // rISRETURNDataGridViewTextBoxColumn1
            // 
            this.rISRETURNDataGridViewTextBoxColumn1.DataPropertyName = "R_ISRETURN";
            this.rISRETURNDataGridViewTextBoxColumn1.FalseValue = "0";
            this.rISRETURNDataGridViewTextBoxColumn1.HeaderText = "반납 여부";
            this.rISRETURNDataGridViewTextBoxColumn1.Name = "rISRETURNDataGridViewTextBoxColumn1";
            this.rISRETURNDataGridViewTextBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.rISRETURNDataGridViewTextBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.rISRETURNDataGridViewTextBoxColumn1.TrueValue = "1";
            // 
            // lATEDataGridViewTextBoxColumn
            // 
            this.lATEDataGridViewTextBoxColumn.DataPropertyName = "LATE";
            this.lATEDataGridViewTextBoxColumn.HeaderText = "벌금";
            this.lATEDataGridViewTextBoxColumn.Name = "lATEDataGridViewTextBoxColumn";
            // 
            // vIEWLATEFEE3BindingSource
            // 
            this.vIEWLATEFEE3BindingSource.DataMember = "VIEW_LATEFEE3";
            this.vIEWLATEFEE3BindingSource.DataSource = this.dataSet2;
            // 
            // dataSet2
            // 
            this.dataSet2.DataSetName = "DataSet2";
            this.dataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.AliceBlue;
            this.tabPage3.Controls.Add(this.button4);
            this.tabPage3.Controls.Add(this.textBox5);
            this.tabPage3.Controls.Add(this.label5);
            this.tabPage3.Controls.Add(this.dataGridView4);
            this.tabPage3.Font = new System.Drawing.Font("휴먼편지체", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tabPage3.Location = new System.Drawing.Point(4, 31);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(989, 468);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "재고 위치";
            // 
            // button4
            // 
            this.button4.Font = new System.Drawing.Font("휴먼편지체", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button4.Location = new System.Drawing.Point(240, 16);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(86, 30);
            this.button4.TabIndex = 3;
            this.button4.Text = "검색";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // textBox5
            // 
            this.textBox5.Font = new System.Drawing.Font("휴먼편지체", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox5.Location = new System.Drawing.Point(87, 16);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(114, 27);
            this.textBox5.TabIndex = 2;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("휴먼편지체", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label5.Location = new System.Drawing.Point(21, 20);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(40, 22);
            this.label5.TabIndex = 1;
            this.label5.Text = "제목";
            // 
            // dataGridView4
            // 
            this.dataGridView4.AutoGenerateColumns = false;
            this.dataGridView4.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView4.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.bNAMEDataGridViewTextBoxColumn2,
            this.bLOCATIONDataGridViewTextBoxColumn});
            this.dataGridView4.DataSource = this.lOCATIONBindingSource;
            this.dataGridView4.Location = new System.Drawing.Point(23, 59);
            this.dataGridView4.Name = "dataGridView4";
            this.dataGridView4.RowTemplate.Height = 23;
            this.dataGridView4.Size = new System.Drawing.Size(303, 381);
            this.dataGridView4.TabIndex = 0;
            // 
            // bNAMEDataGridViewTextBoxColumn2
            // 
            this.bNAMEDataGridViewTextBoxColumn2.DataPropertyName = "B_NAME";
            this.bNAMEDataGridViewTextBoxColumn2.HeaderText = "이름";
            this.bNAMEDataGridViewTextBoxColumn2.Name = "bNAMEDataGridViewTextBoxColumn2";
            // 
            // bLOCATIONDataGridViewTextBoxColumn
            // 
            this.bLOCATIONDataGridViewTextBoxColumn.DataPropertyName = "B_LOCATION";
            this.bLOCATIONDataGridViewTextBoxColumn.HeaderText = "위치";
            this.bLOCATIONDataGridViewTextBoxColumn.Name = "bLOCATIONDataGridViewTextBoxColumn";
            // 
            // lOCATIONBindingSource
            // 
            this.lOCATIONBindingSource.DataMember = "LOCATION";
            this.lOCATIONBindingSource.DataSource = this.dataSet2;
            // 
            // oWNBOOKTableAdapter
            // 
            this.oWNBOOKTableAdapter.ClearBeforeFill = true;
            // 
            // oracleConnection1
            // 
            this.oracleConnection1.ConnectionString = "DATA SOURCE=ORARA;USER ID=A5293460;password=qew164712486";
            // 
            // oracleCommand1
            // 
            this.oracleCommand1.Connection = this.oracleConnection1;
            oracleParameter1.OracleDbType = Oracle.DataAccess.Client.OracleDbType.Varchar2;
            oracleParameter1.ParameterName = "aa";
            oracleParameter2.OracleDbType = Oracle.DataAccess.Client.OracleDbType.Varchar2;
            oracleParameter2.ParameterName = "bb";
            oracleParameter3.OracleDbType = Oracle.DataAccess.Client.OracleDbType.Date;
            oracleParameter3.ParameterName = "cc";
            oracleParameter4.OracleDbType = Oracle.DataAccess.Client.OracleDbType.Varchar2;
            oracleParameter4.ParameterName = "dd";
            oracleParameter5.OracleDbType = Oracle.DataAccess.Client.OracleDbType.Date;
            oracleParameter5.ParameterName = "ee";
            oracleParameter6.OracleDbType = Oracle.DataAccess.Client.OracleDbType.Int16;
            oracleParameter6.ParameterName = "ff";
            oracleParameter7.OracleDbType = Oracle.DataAccess.Client.OracleDbType.Int16;
            oracleParameter7.ParameterName = "gg";
            oracleParameter8.OracleDbType = Oracle.DataAccess.Client.OracleDbType.Varchar2;
            oracleParameter8.ParameterName = "hh";
            this.oracleCommand1.Parameters.Add(oracleParameter1);
            this.oracleCommand1.Parameters.Add(oracleParameter2);
            this.oracleCommand1.Parameters.Add(oracleParameter3);
            this.oracleCommand1.Parameters.Add(oracleParameter4);
            this.oracleCommand1.Parameters.Add(oracleParameter5);
            this.oracleCommand1.Parameters.Add(oracleParameter6);
            this.oracleCommand1.Parameters.Add(oracleParameter7);
            this.oracleCommand1.Parameters.Add(oracleParameter8);
            this.oracleCommand1.Transaction = null;
            // 
            // oracleCommand2
            // 
            this.oracleCommand2.Connection = this.oracleConnection1;
            this.oracleCommand2.Transaction = null;
            // 
            // rENTTableAdapter
            // 
            this.rENTTableAdapter.ClearBeforeFill = true;
            // 
            // oracleCommand3
            // 
            this.oracleCommand3.Connection = this.oracleConnection1;
            this.oracleCommand3.Transaction = null;
            // 
            // oracleCommand4
            // 
            this.oracleCommand4.Connection = this.oracleConnection1;
            this.oracleCommand4.Transaction = null;
            // 
            // oracleCommand5
            // 
            this.oracleCommand5.Connection = this.oracleConnection1;
            this.oracleCommand5.Transaction = null;
            // 
            // lOCATIONTableAdapter
            // 
            this.lOCATIONTableAdapter.ClearBeforeFill = true;
            // 
            // vIEW_LATEFEE3TableAdapter
            // 
            this.vIEW_LATEFEE3TableAdapter.ClearBeforeFill = true;
            // 
            // mEMBERTableAdapter
            // 
            this.mEMBERTableAdapter.ClearBeforeFill = true;
            // 
            // 직원
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(1014, 519);
            this.Controls.Add(this.tabControl1);
            this.Font = new System.Drawing.Font("휴먼엑스포", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Name = "직원";
            this.Text = "직원";
            this.Load += new System.EventHandler(this.Form7_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rENTBindingSource)).EndInit();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.oWNBOOKBindingSource)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mEMBERBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vIEWLATEFEE3BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet2)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lOCATIONBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DataSet1 dataSet1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.DataGridViewTextBoxColumn rENTDATEDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource oWNBOOKBindingSource;
        private DataSet1TableAdapters.OWNBOOKTableAdapter oWNBOOKTableAdapter;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private Oracle.DataAccess.Client.OracleConnection oracleConnection1;
        private Oracle.DataAccess.Client.OracleCommand oracleCommand1;
        private Oracle.DataAccess.Client.OracleCommand oracleCommand2;
        private System.Windows.Forms.BindingSource rENTBindingSource;
        private DataSet1TableAdapters.RENTTableAdapter rENTTableAdapter;
        private Oracle.DataAccess.Client.OracleCommand oracleCommand3;
        private Oracle.DataAccess.Client.OracleCommand oracleCommand4;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DataGridView dataGridView3;
        private DataSet2 dataSet2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.DataGridView dataGridView4;
        private System.Windows.Forms.BindingSource lOCATIONBindingSource;
        private DataSet2TableAdapters.LOCATIONTableAdapter lOCATIONTableAdapter;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label5;
        private Oracle.DataAccess.Client.OracleCommand oracleCommand5;
        private System.Windows.Forms.DataGridViewTextBoxColumn mIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn oIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn rRENTDATEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn bNAMEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn rDEADLINEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn rISRETURNDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn rISEXTENDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn rSTAFFDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn bNAMEDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn oIDDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewCheckBoxColumn oISRENTDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn oISRESERVEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn oSTATUSDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn bNAMEDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn bLOCATIONDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.BindingSource vIEWLATEFEE3BindingSource;
        private DataSet2TableAdapters.VIEW_LATEFEE3TableAdapter vIEW_LATEFEE3TableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn mIDDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn mNAMEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn mEMAILDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn bNAMEDataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewCheckBoxColumn rISRETURNDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn lATEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridView dataGridView5;
        private System.Windows.Forms.BindingSource mEMBERBindingSource;
        private DataSet1TableAdapters.MEMBERTableAdapter mEMBERTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn mIDDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn mPASSWORDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn mNAMEDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn mPHONEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn mEMAILDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn mLATEFEEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn mGRADEDataGridViewTextBoxColumn;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button9;
    }
}